import express from 'express';
import { InferenceClient } from '@huggingface/inference';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const port = process.env.PORT || 3000;
const here = path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(here, 'public')));

function client() {
  if (!process.env.HF_TOKEN) {
    const err = new Error('Falta configurar HF_TOKEN no servidor. Cria um token no Hugging Face e guarda-o como variável secreta HF_TOKEN.');
    err.status = 503;
    throw err;
  }
  return new InferenceClient(process.env.HF_TOKEN);
}

app.get('/api/status', (_req, res) => {
  res.json({ imageConfigured: Boolean(process.env.HF_TOKEN), videoConfigured: Boolean(process.env.HF_TOKEN), message: process.env.HF_TOKEN ? 'Token configurado; disponibilidade depende do modelo/provedor e dos créditos.' : 'Backend preparado; falta configurar o token secreto HF_TOKEN.' });
});

app.post('/api/image', async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    if (!prompt) return res.status(400).json({ error: 'Escreve uma descrição para a imagem.' });
    if (prompt.length > 1500) return res.status(400).json({ error: 'O prompt pode ter no máximo 1500 caracteres.' });
    const hf = client();
    const model = String(req.body?.model || 'black-forest-labs/FLUX.1-schnell');
    const blob = await hf.textToImage({ model, inputs: prompt });
    const buffer = Buffer.from(await blob.arrayBuffer());
    res.json({ image: `data:${blob.type || 'image/png'};base64,${buffer.toString('base64')}`, model });
  } catch (e) {
    console.error('Image generation error:', e?.message || e);
    res.status(e.status || 502).json({ error: e.status === 503 ? e.message : `Não consegui gerar a imagem. Confere o token, os créditos e se o modelo está disponível. Detalhe: ${e.message || 'erro do provedor'}` });
  }
});

app.post('/api/video', async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    if (!prompt) return res.status(400).json({ error: 'Escreve uma descrição para o vídeo.' });
    if (prompt.length > 1200) return res.status(400).json({ error: 'O prompt pode ter no máximo 1200 caracteres.' });
    const hf = client();
    const model = String(req.body?.model || 'Wan-AI/Wan2.2-TI2V-5B');
    const blob = await hf.textToVideo({ provider: 'fal-ai', model, inputs: prompt });
    const buffer = Buffer.from(await blob.arrayBuffer());
    res.json({ video: `data:${blob.type || 'video/mp4'};base64,${buffer.toString('base64')}`, model });
  } catch (e) {
    console.error('Video generation error:', e?.message || e);
    res.status(e.status || 502).json({ error: `Não consegui gerar o vídeo. A geração de vídeo pode exigir um provedor compatível, créditos ou uma chave configurada. Detalhe: ${e.message || 'erro do provedor'}` });
  }
});

app.listen(port, () => console.log(`EstrelaMotion AI a correr na porta ${port}`));
